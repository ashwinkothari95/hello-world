const template = `
  <div class="container">

	  <h1>Bill Viewer</h1>
    <hello-world></hello-world>
	  <billing-period-select
      billing-periods="$ctrl.billingPeriods"
      on-select-billing-period="$ctrl.fetchBill"
    >
    </billing-period-select>

	  <div ng-show="$ctrl.isBillFetching">
		  Fetching bill...
	  </div>
	  <div ng-show="!$ctrl.isBillFetching">
		  <bill bill="$ctrl.selectedBill">
		  </bill>
	  </div>

  </div>
`;

const controller = ['billApiService', function (billApiService) {

  this.billingPeriods = [
    '2018-06',
    '2018-05',
    '2018-04'
  ];

  this.fetchBill = (billingPeriod) => {

    this.isBillFetching = true;

    billApiService.fetchBill(billingPeriod)
      .then((bill) => {
        this.selectedBill = bill;
        this.isBillFetching = false;

      });

  };

  /*this.fetchBill = (billingPeriod) => {
 
    this.isBillFetching = true;
    if(billingPeriod=='2018-04'){
      this.selectedBill =  {
        "id": "2018-04",
        "amount": "2546.12",
        "dueDate": "2018-05-15"
      }

    }
    if(billingPeriod=='2018-05'){
      this.selectedBill = {
        "id": "2018-05",
        "amount": "2966.50",
        "dueDate": "2018-06-15"
      }

    }
    if(billingPeriod=='2018-06'){
      this.selectedBill = {
        "id": "2018-06",
        "amount": "1839.38",
        "dueDate": "2018-07-15"
      }
    }
    console.log(this.selectedBill)
    this.isBillFetching = false;
  };*/

  this.$onInit = () => {

    this.fetchBill(this.billingPeriods[0]);

  }

},];

export default {
  template,
  controller,
};