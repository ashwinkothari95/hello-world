import React, { Component } from 'react';
import './HelloWorld.css';


class HelloWorld extends Component {
    constructor (props) {
        super (props);
        this.state = { greeting: 'Hello' };
    }
    callHelpMethod() {
       window.alert("Helper method called");
    }
    render () {
        return (
            <div>
            <button onClick={this.callHelpMethod}><span role="img" aria-label="Delete" title="Delete">HELP</span></button>
            </div>
        );
    }
}
export default HelloWorld;