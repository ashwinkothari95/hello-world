import React from 'react';

export default ({
  billingPeriods,
  onSelectBillingPeriod
}) => {

  const selectBillingPeriod = (event) => {
    console.log(event.target.value)
    onSelectBillingPeriod(event.target.value);

  };

  return (
    <select
      className="form-control"
      onChange={selectBillingPeriod}
    >
      {billingPeriods.map((billingPeriod) => (
        <option
          key={billingPeriod}
          value={billingPeriod}
        >
          {billingPeriod}
        </option>
      ))}
    </select>
  );

}