export default ['$http', function ($http) {

  this.fetchBill = (billingPeriod) => {
    return $http.get(`/api/bill-${billingPeriod}.json`)
      .then((successResponse) =>{
        if(billingPeriod=='2018-04'){
          return  {
            "id": "2018-04",
            "amount": "2546.12",
            "dueDate": "2018-05-15"
          }
    
        }
        if(billingPeriod=='2018-05'){
          return {
            "id": "2018-05",
            "amount": "2966.50",
            "dueDate": "2018-06-15"
          }
    
        }
        if(billingPeriod=='2018-06'){
          return  {
            "id": "2018-06",
            "amount": "1839.38",
            "dueDate": "2018-07-15"
          }
        }
      } 
    )
  };

}];